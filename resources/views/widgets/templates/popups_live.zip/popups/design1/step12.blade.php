<div class="display_div d1 step_12 thankyou-page" @if(isset($show) && $show == 1) style="display: inline-block;" @else style="display: none;" @endif>
	<div class="thankyou"><h2>Your Message has been Sent!</h2></div>
</div>
<link rel="stylesheet" type="text/css" href="/assets/css/style.css">