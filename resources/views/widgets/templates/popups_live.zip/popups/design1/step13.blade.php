<div class="display_div d1 step_13 thankyou-page" @if(isset($show) && $show == 1) style="display: inline-block;" @else style="display: none;" @endif>
	<div class="thankyou"><h2>Please Reconnect to {{$provider}} service!</h2></div>
</div>
<link rel="stylesheet" type="text/css" href="/assets/css/style.css">